import { useEffect, useRef, useState } from "react";
import { Html5Qrcode, Html5QrcodeSupportedFormats } from "html5-qrcode";
import { X, Zap, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";

interface ScannerProps {
  onScan: (decodedText: string) => void;
  onClose: () => void;
}

export function Scanner({ onScan, onClose }: ScannerProps) {
  const [isScanning, setIsScanning] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const scannerRegionId = "html5-qrcode-reader";

  useEffect(() => {
    // Initialize scanner
    const initScanner = async () => {
      try {
        const formatsToSupport = [
          Html5QrcodeSupportedFormats.QR_CODE,
          Html5QrcodeSupportedFormats.UPC_A,
          Html5QrcodeSupportedFormats.UPC_E,
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.EAN_8,
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.CODE_39,
        ];

        // Pass formats to constructor
        const html5QrCode = new Html5Qrcode(scannerRegionId, { formatsToSupport, verbose: false });
        scannerRef.current = html5QrCode;

        await html5QrCode.start(
          { facingMode: "environment" },
          {
            fps: 20, // High FPS for speed
            qrbox: { width: 250, height: 250 },
            aspectRatio: 1.0,
          },
          (decodedText) => {
            // Success callback
            if (isScanning) {
              onScan(decodedText);
            }
          },
          (errorMessage) => {
            // parse error, ignore it.
          }
        );
      } catch (err) {
        console.error("Error starting scanner", err);
        setError("Could not access camera. Please ensure permissions are granted.");
      }
    };

    // Small delay to ensure DOM is ready
    const timer = setTimeout(() => {
        initScanner();
    }, 100);

    return () => {
      clearTimeout(timer);
      if (scannerRef.current && scannerRef.current.isScanning) {
        scannerRef.current.stop().then(() => {
          scannerRef.current?.clear();
        }).catch(err => console.error("Failed to stop scanner", err));
      }
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center">
      {/* Header */}
      <div className="absolute top-0 w-full p-4 flex justify-between items-center z-10 bg-gradient-to-b from-black/80 to-transparent">
        <div className="flex items-center gap-2 text-primary">
          <Zap className="h-5 w-5 fill-primary" />
          <span className="font-mono font-bold tracking-widest text-sm">RAPID.SCAN</span>
        </div>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={onClose}
          className="text-white hover:bg-white/10 hover:text-white rounded-full"
        >
          <X className="h-6 w-6" />
        </Button>
      </div>

      {/* Scanner Viewport */}
      <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
        <div id={scannerRegionId} className="w-full h-full object-cover [&>video]:object-cover [&>video]:w-full [&>video]:h-full" />
        
        {/* Overlay UI */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Dark overlay with clear center */}
          <div className="absolute inset-0 bg-black/40">
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-transparent border-2 border-primary/50 rounded-lg shadow-[0_0_20px_rgba(34,197,94,0.3)]">
                {/* Corners */}
                <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-primary -mt-1 -ml-1"></div>
                <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-primary -mt-1 -mr-1"></div>
                <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-primary -mb-1 -ml-1"></div>
                <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-primary -mb-1 -mr-1"></div>
                
                {/* Scan Line */}
                <div className="absolute top-0 left-0 w-full h-1 bg-primary/80 shadow-[0_0_10px_rgba(34,197,94,0.8)] animate-[scan_2s_linear_infinite]"></div>
             </div>
          </div>
          
          {/* Target Text */}
          <div className="absolute top-[65%] w-full text-center">
             <p className="text-white/80 font-mono text-xs tracking-widest uppercase bg-black/50 inline-block px-3 py-1 rounded">Alinee el código dentro del marco</p>
          </div>
        </div>

        {error && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/90 p-6 text-center">
                <div className="max-w-xs space-y-4">
                    <p className="text-destructive font-bold">{error}</p>
                    <Button variant="outline" onClick={onClose} className="border-white/20 text-white">Cerrar</Button>
                </div>
            </div>
        )}
      </div>

      {/* Footer controls */}
      <div className="absolute bottom-0 w-full p-8 bg-gradient-to-t from-black via-black/80 to-transparent flex justify-center pb-12">
        <div className="text-white/50 font-mono text-xs flex items-center gap-2">
           <Loader2 className="h-3 w-3 animate-spin" />
           SISTEMA ACTIVO
        </div>
      </div>
    </div>
  );
}
