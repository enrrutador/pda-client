import { Link, useLocation } from "wouter";
import { LayoutDashboard, ScanLine, Box, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: LayoutDashboard, label: "Resumen" },
    { href: "/scan", icon: ScanLine, label: "Escanear", primary: true },
    { href: "/inventory", icon: Box, label: "Inventario" },
    // { href: "/settings", icon: Settings, label: "Config" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border pb-safe">
      <div className="flex items-center justify-around h-16 px-2">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href}>
             <div className={cn(
                "flex flex-col items-center justify-center w-full h-full gap-1 active:scale-95 transition-transform cursor-pointer",
                location === item.href ? "text-primary" : "text-muted-foreground",
                item.primary && "-mt-6"
             )}>
                {item.primary ? (
                    <div className="bg-primary text-primary-foreground p-4 rounded-full shadow-[0_0_20px_rgba(34,197,94,0.4)] border-4 border-background">
                        <item.icon className="h-6 w-6" />
                    </div>
                ) : (
                    <item.icon className="h-5 w-5" />
                )}
                {!item.primary && (
                    <span className="text-[10px] font-mono tracking-wide uppercase">{item.label}</span>
                )}
             </div>
          </Link>
        ))}
      </div>
    </nav>
  );
}
