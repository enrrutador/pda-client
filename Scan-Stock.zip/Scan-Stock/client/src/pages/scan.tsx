import { useInventory, InventoryItem } from "@/lib/inventory-store";
import { Scanner } from "@/components/Scanner";
import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, CheckCircle2, AlertTriangle, Box as BoxIcon, Loader2, Plus, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export default function ScanPage() {
  const [, setLocation] = useLocation();
  const { scanItem, addItem } = useInventory();
  const [lastScanned, setLastScanned] = useState<any>(null);
  const [scanStatus, setScanStatus] = useState<'idle' | 'success' | 'error' | 'not_found'>('idle');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newBarcode, setNewBarcode] = useState("");
  const [newItemName, setNewItemName] = useState("");

  const handleScan = async (barcode: string) => {
    if (showAddForm) return;

    if (lastScanned?.barcode === barcode && Date.now() - new Date(lastScanned.timestamp).getTime() < 2000) {
        return;
    }

    const result = await scanItem(barcode);
    
    if (result.success) {
      setScanStatus('success');
      const itemWithTime = { ...result.item, timestamp: new Date().toISOString() };
      setLastScanned(itemWithTime);
      toast({
        title: "ESCANEO EXITOSO",
        description: `${result.item?.name} - ${result.message}`,
        className: "border-primary text-primary bg-background font-mono"
      });
      if (navigator.vibrate) navigator.vibrate(50);
      setShowAddForm(false);
    } else {
      setScanStatus('not_found');
      setNewBarcode(barcode);
      setShowAddForm(true);
      if (navigator.vibrate) navigator.vibrate([100, 50, 100]);
    }
  };

  const handleAddNew = () => {
    if (!newItemName.trim()) return;

    const newItem: InventoryItem = {
      id: Math.random().toString(36).substr(2, 9),
      name: newItemName,
      barcode: newBarcode,
      sku: `SKU-${newBarcode.slice(-4)}`,
      category: "General",
      price: 0,
      quantity: 1,
      lastScanned: new Date().toISOString(),
      location: "RX-NEW"
    };

    addItem(newItem);
    setScanStatus('success');
    setLastScanned({ ...newItem, timestamp: new Date() });
    setShowAddForm(false);
    setNewItemName("");
    
    toast({
      title: "ARTÍCULO CREADO",
      description: `Se ha añadido ${newItemName} al inventario.`,
      className: "border-primary text-primary bg-background font-mono"
    });
    
    setTimeout(() => setScanStatus('idle'), 1500);
  };

  return (
    <div className="h-screen bg-black flex flex-col">
       {!lastScanned && !showAddForm && (
         <Scanner 
           onScan={handleScan} 
           onClose={() => setLocation("/")}
         />
       )}
       
       {/* Searching/Add Form Overlay */}
       <AnimatePresence>
         {showAddForm && (
           <motion.div 
             initial={{ opacity: 0 }}
             animate={{ opacity: 1 }}
             exit={{ opacity: 0 }}
             className="fixed inset-0 z-[70] bg-black/90 backdrop-blur-md flex items-center justify-center p-6"
           >
              <Card className="w-full max-w-sm bg-card border-primary/50">
                 <CardContent className="p-6 space-y-4">
                    <div className="flex items-center gap-2 text-primary mb-2">
                        <Plus className="h-5 w-5" />
                        <h2 className="font-mono font-bold tracking-tighter uppercase">Nuevo Artículo</h2>
                    </div>
                    
                    <div className="space-y-2">
                        <label className="text-[10px] font-mono text-muted-foreground uppercase">Código Detectado</label>
                        <div className="bg-muted p-2 rounded font-mono text-sm border border-border">{newBarcode}</div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-[10px] font-mono text-muted-foreground uppercase">Nombre del Producto</label>
                        <Input 
                            autoFocus
                            value={newItemName}
                            onChange={(e) => setNewItemName(e.target.value)}
                            placeholder="Ej. Tornillo M8..." 
                            className="bg-background border-border focus-visible:border-primary font-sans"
                        />
                    </div>

                    <div className="flex gap-2 pt-2">
                        <Button 
                            variant="ghost" 
                            onClick={() => setShowAddForm(false)}
                            className="flex-1 font-mono text-xs uppercase"
                        >
                            Cancelar
                        </Button>
                        <Button 
                            onClick={handleAddNew}
                            disabled={!newItemName.trim()}
                            className="flex-1 bg-primary text-primary-foreground font-mono text-xs uppercase"
                        >
                            Guardar
                        </Button>
                    </div>
                 </CardContent>
              </Card>
           </motion.div>
         )}
       </AnimatePresence>

       {/* Last Scanned Overlay */}
       <AnimatePresence>
         {lastScanned && (
           <motion.div 
             initial={{ opacity: 0, y: 100 }}
             animate={{ opacity: 1, y: 0 }}
             exit={{ opacity: 0, y: 100 }}
             className="fixed bottom-0 left-0 right-0 z-[60] p-4 pb-8 bg-card border-t border-border"
           >
              <div className="flex items-start gap-4">
                 <div className={cn(
                    "p-3 rounded-lg flex items-center justify-center shrink-0",
                    scanStatus === 'success' ? "bg-primary/20 text-primary" : "bg-destructive/20 text-destructive"
                 )}>
                    {scanStatus === 'success' ? <CheckCircle2 className="h-8 w-8" /> : <AlertTriangle className="h-8 w-8" />}
                 </div>
                 
                 <div className="space-y-1 flex-1">
                    <div className="flex justify-between items-start">
                        <p className="text-[10px] text-white/60 font-mono uppercase tracking-[0.2em] font-bold">
                            {scanStatus === 'success' ? "Registro de Activo" : "Error de Lectura"}
                        </p>
                        <Button variant="ghost" size="sm" onClick={() => setLastScanned(null)} className="h-8 w-8 p-0 hover:bg-white/10">
                            <X className="h-5 w-5" />
                        </Button>
                    </div>
                    <h3 className="font-display font-bold text-4xl leading-none text-white uppercase tracking-tight mb-2">{lastScanned.name}</h3>
                    <div className="grid grid-cols-1 gap-4 mt-4">
                        <div className="flex items-center justify-between p-5 bg-slate-800/60 rounded-sm border-l-4 border-primary shadow-lg">
                            <span className="text-sm font-bold text-slate-400 uppercase tracking-[0.2em]">Stock Actual</span>
                            <span className="text-6xl font-black text-primary font-display">{lastScanned.quantity}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-4 bg-slate-800/40 rounded-sm border border-slate-700/50">
                                <p className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-1">Precio Unitario</p>
                                <p className="text-3xl font-black text-white font-display">${lastScanned.price?.toFixed(2)}</p>
                            </div>
                            <div className="p-4 bg-slate-800/40 rounded-sm border border-slate-700/50">
                                <p className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-1">Ubicación Pasillo</p>
                                <p className="text-2xl font-black text-white uppercase font-display">{lastScanned.location || '---'}</p>
                            </div>
                        </div>
                    </div>
                    <div className="mt-4 pt-3 border-t border-border/50">
                        <p className="text-[10px] text-muted-foreground font-mono uppercase mb-1">Código / SKU</p>
                        <div className="flex justify-between items-center">
                            <p className="font-mono text-xs">{lastScanned.barcode}</p>
                            <p className="font-mono text-[10px] bg-muted px-1.5 py-0.5 rounded">{lastScanned.sku}</p>
                        </div>
                    </div>
                 </div>
              </div>
           </motion.div>
         )}
       </AnimatePresence>
    </div>
  );
}

// Helper for class names since I can't import clsx/tw-merge in this specific file context easily without utility file
function cn(...classes: (string | undefined | null | false)[]) {
  return classes.filter(Boolean).join(' ');
}
