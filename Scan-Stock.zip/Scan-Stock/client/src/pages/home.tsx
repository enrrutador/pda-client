import { useInventory } from "@/lib/inventory-store";
import { BottomNav } from "@/components/BottomNav";
import { Card, CardContent } from "@/components/ui/card";
import { Package, Search, Download, RefreshCw, FileText, Table, Loader2, Upload } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";
import { useRef } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from "react";

export default function HomePage() {
  const { items, recentScans, addItem } = useInventory();
  const [isExporting, setIsExporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const totalStock = items.reduce((acc, item) => acc + item.quantity, 0);
  const totalValue = items.reduce((acc, item) => acc + (item.quantity * item.price), 0);

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        const lines = text.split("\n");
        const headers = lines[0].split(",");
        
        let importCount = 0;
        for (let i = 1; i < lines.length; i++) {
          if (!lines[i].trim()) continue;
          const values = lines[i].split(",");
          
          // Mapeo básico de columnas CSV a objeto InventoryItem
          const newItem = {
            id: values[0] || Math.random().toString(36).substr(2, 9),
            name: values[1]?.replace(/"/g, "") || "Producto Importado",
            sku: values[2] || "SKU-IMP",
            category: values[3] || "General",
            price: parseFloat(values[4]) || 0,
            quantity: parseInt(values[5]) || 0,
            location: values[6] || "ALMACÉN",
            barcode: values[7] || "0000000000000",
            lastScanned: new Date().toISOString()
          };
          
          addItem(newItem);
          importCount++;
        }

        toast({
          title: "IMPORTACIÓN EXITOSA",
          description: `Se han importado ${importCount} productos correctamente.`,
          className: "border-primary text-primary bg-background font-mono"
        });
      } catch (error) {
        toast({
          title: "ERROR DE IMPORTACIÓN",
          description: "El formato del archivo no es válido.",
          variant: "destructive"
        });
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleExport = async (format: 'csv' | 'xlsx') => {
    setIsExporting(true);
    try {
      const headers = ["ID", "Nombre", "SKU", "Categoria", "Precio", "Stock", "Ubicacion", "Codigo de Barras"];
      const rows = items.map(item => [
        item.id,
        item.name,
        item.sku,
        item.category,
        item.price,
        item.quantity,
        item.location,
        item.barcode
      ]);

      let content = "";
      let extension = "";
      let mimeType = "";

      if (format === 'csv') {
        content = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
        extension = ".csv";
        mimeType = 'text/csv;charset=utf-8;';
      } else {
        content = [headers.join("\t"), ...rows.map(r => r.join("\t"))].join("\n");
        extension = ".xls";
        mimeType = 'application/vnd.ms-excel;charset=utf-8;';
      }

      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `Datos${extension}`;
      document.body.appendChild(link);
      link.click();
      
      setTimeout(() => {
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, 100);

      toast({
        title: "EXPORTACIÓN EXITOSA",
        description: `El archivo "Datos${extension}" ha sido exportado.`,
        className: "border-primary text-primary bg-background font-mono"
      });
    } catch (error) {
      console.error("Export error:", error);
      toast({
        title: "ERROR EN EXPORTACIÓN",
        description: "No se pudo generar el archivo.",
        variant: "destructive"
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleSync = () => {
    toast({
      title: "SINCRONIZANDO...",
      description: "Conectando con el servidor central...",
      className: "border-primary text-primary bg-background font-mono"
    });
    
    // Simular actualización de stock al sincronizar
    setTimeout(() => {
      toast({
        title: "SINCRONIZACIÓN COMPLETA",
        description: "Base de datos actualizada correctamente. Los niveles de stock están al día.",
        className: "border-primary text-primary bg-background font-mono"
      });
    }, 1500);
  };

  return (
    <div className="min-h-screen pb-20 bg-background font-sans">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-md border-b border-border p-4">
        <div className="flex justify-between items-center mb-4">
            <div>
                <h1 className="text-xl font-bold tracking-tight">INVENTARIO.OS</h1>
                <p className="text-xs text-muted-foreground font-mono">v2.4.0-ESTABLE</p>
            </div>
            <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center border border-primary/50">
                <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
            </div>
        </div>
        
        <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input 
                placeholder="Buscar SKU / Código..." 
                className="pl-9 bg-muted/50 border-transparent focus-visible:bg-background focus-visible:border-primary font-mono text-sm"
            />
        </div>
      </header>

      <div className="p-4 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
            <Card className="bg-card/50 border-border">
                <CardContent className="p-4">
                    <div className="text-xs text-muted-foreground font-mono uppercase mb-1">Stock Total</div>
                    <div className="text-2xl font-bold font-mono text-primary">{totalStock.toLocaleString()}</div>
                </CardContent>
            </Card>
            <Card className="bg-card/50 border-border">
                <CardContent className="p-4">
                    <div className="text-xs text-muted-foreground font-mono uppercase mb-1">Valor</div>
                    <div className="text-2xl font-bold font-mono">${totalValue.toLocaleString()}</div>
                </CardContent>
            </Card>
        </div>

        {/* Recent Activity */}
        <section>
            <div className="flex items-center justify-between mb-3">
                <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Escaneos Recientes</h2>
                <span className="text-xs font-mono text-primary cursor-pointer hover:underline">VER LOG</span>
            </div>
            
            <div className="space-y-2">
                {recentScans.length === 0 ? (
                    <div className="text-center py-8 border border-dashed border-muted rounded-lg">
                        <Package className="h-8 w-8 text-muted-foreground mx-auto mb-2 opacity-50" />
                        <p className="text-sm text-muted-foreground">Sin actividad reciente</p>
                    </div>
                ) : (
                    recentScans.map((item) => (
                        <div key={`${item.id}-${item.lastScanned}`} className="flex items-center gap-3 bg-card p-3 rounded-lg border border-border/50 hover:border-primary/30 transition-colors group">
                            <div className="h-10 w-10 bg-muted rounded flex items-center justify-center shrink-0 group-hover:bg-primary/10 transition-colors">
                                <Package className="h-5 w-5 text-foreground group-hover:text-primary transition-colors" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <h3 className="font-medium text-sm truncate">{item.name}</h3>
                                <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
                                    <span>{item.sku}</span>
                                    <span className="w-1 h-1 rounded-full bg-muted-foreground/50" />
                                    <span>{new Date(item.lastScanned).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                </div>
                            </div>
                            <div className="text-right">
                                <div className="font-mono font-bold text-sm">{item.quantity}</div>
                                <div className="text-[10px] text-muted-foreground uppercase">Unidades</div>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </section>
        
        {/* Quick Actions */}
        <section>
            <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3">Sistema</h2>
            <div className="grid grid-cols-2 gap-3">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild disabled={isExporting}>
                    <button className="flex flex-col items-center justify-center gap-2 p-4 rounded-lg bg-muted/30 hover:bg-muted/50 border border-transparent hover:border-primary/20 transition-all active:scale-95 disabled:opacity-50">
                        {isExporting ? <Loader2 className="h-5 w-5 animate-spin text-primary" /> : <Download className="h-5 w-5 text-primary" />}
                        <span className="text-xs font-mono uppercase">{isExporting ? "Exportando..." : "Exportar Datos"}</span>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-card border-border font-mono">
                    <DropdownMenuItem onClick={() => handleExport('csv')} className="gap-2 cursor-pointer">
                      <FileText className="h-4 w-4 text-primary" />
                      <span>CSV (.csv)</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleExport('xlsx')} className="gap-2 cursor-pointer">
                      <Table className="h-4 w-4 text-primary" />
                      <span>EXCEL (.xls)</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <input 
                  type="file" 
                  accept=".csv" 
                  className="hidden" 
                  ref={fileInputRef} 
                  onChange={handleImport}
                />
                
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center justify-center gap-2 p-4 rounded-lg bg-muted/30 hover:bg-muted/50 border border-transparent hover:border-primary/20 transition-all active:scale-95"
                >
                    <Upload className="h-5 w-5 text-accent-foreground" />
                    <span className="text-xs font-mono uppercase">Importar Datos</span>
                </button>
            </div>
        </section>
      </div>

      <BottomNav />
    </div>
  );
}
