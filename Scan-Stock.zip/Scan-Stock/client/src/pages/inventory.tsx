import { useInventory, InventoryItem } from "@/lib/inventory-store";
import { BottomNav } from "@/components/BottomNav";
import { Package, Search, Plus, Minus, Edit3, X, Save } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function InventoryPage() {
  const { items, updateQuantity, updateItem } = useInventory();
  const [search, setSearch] = useState("");
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);

  const filteredItems = items.filter(item => 
    item.name.toLowerCase().includes(search.toLowerCase()) ||
    item.sku.toLowerCase().includes(search.toLowerCase()) ||
    item.barcode.includes(search) ||
    item.category.toLowerCase().includes(search.toLowerCase())
  ).sort((a, b) => new Date(b.lastScanned).getTime() - new Date(a.lastScanned).getTime());

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingItem) {
        updateItem(editingItem.id, editingItem);
        setEditingItem(null);
    }
  };

  return (
    <div className="min-h-screen pb-20 bg-background font-sans">
      <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-md border-b border-border p-4">
        <h1 className="text-xl font-bold tracking-tight mb-4">Lista de Inventario</h1>
        <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filtrar artículos..." 
                className="pl-9 bg-muted/50 border-transparent focus-visible:bg-background focus-visible:border-primary font-mono text-sm"
            />
        </div>
      </header>

      <div className="p-4 space-y-2">
        {filteredItems.length === 0 ? (
            <div className="text-center py-12">
                <p className="text-muted-foreground font-mono">No se encontraron artículos.</p>
            </div>
        ) : (
            filteredItems.map((item) => (
                <div key={item.id} className="flex flex-col bg-card p-4 rounded-lg border border-border/50">
                    <div className="flex justify-between items-center mb-3">
                        <div className="flex-1 mr-4" onClick={() => setEditingItem(item)}>
                            <div className="flex items-center gap-2">
                                <h3 className="font-display font-bold text-xl text-white uppercase leading-tight">{item.name}</h3>
                                <Edit3 className="h-4 w-4 text-primary/50" />
                            </div>
                            <p className="text-xs text-primary font-mono font-bold tracking-widest uppercase">{item.category}</p>
                        </div>
                        <div className="flex items-center gap-4 bg-slate-900 rounded-sm p-1.5 border border-slate-700 shadow-xl">
                            <Button 
                              variant="secondary" 
                              size="icon" 
                              className="h-12 w-12 bg-slate-800 text-white hover:bg-slate-700 active:scale-90 border border-slate-600 shadow-md"
                              onClick={() => updateQuantity(item.id, -1)}
                            >
                              <Minus className="h-8 w-8 stroke-[4px]" />
                            </Button>
                            <span className="w-16 text-center font-display font-black text-5xl text-white drop-shadow-md">{item.quantity}</span>
                            <Button 
                              variant="default" 
                              size="icon" 
                              className="h-12 w-12 bg-primary text-white hover:bg-primary/80 active:scale-90 shadow-lg shadow-primary/30 border border-primary/50"
                              onClick={() => updateQuantity(item.id, 1)}
                            >
                              <Plus className="h-8 w-8 stroke-[4px]" />
                            </Button>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 text-xs font-mono text-muted-foreground mt-2 pt-2 border-t border-border/30">
                        <div>SKU: <span className="text-foreground">{item.sku}</span></div>
                        <div>UBIC: <span className="text-foreground">{item.location}</span></div>
                        <div>PRECIO: <span className="text-primary font-bold">${item.price?.toFixed(2)}</span></div>
                        <div>BAR: <span className="text-foreground">{item.barcode}</span></div>
                    </div>
                </div>
            ))
        )}
      </div>

      <AnimatePresence>
        {editingItem && (
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
                onClick={() => setEditingItem(null)}
            >
                <motion.div 
                    initial={{ y: 100 }}
                    animate={{ y: 0 }}
                    exit={{ y: 100 }}
                    className="w-full max-w-lg"
                    onClick={(e) => e.stopPropagation()}
                >
                    <Card className="bg-slate-900 border-primary shadow-2xl overflow-hidden">
                        <CardHeader className="bg-primary/10 border-b border-primary/20 flex flex-row items-center justify-between py-4">
                            <CardTitle className="font-display text-2xl text-primary uppercase tracking-tight">Editar Producto</CardTitle>
                            <Button variant="ghost" size="icon" onClick={() => setEditingItem(null)} className="text-white hover:bg-white/10">
                                <X className="h-6 w-6" />
                            </Button>
                        </CardHeader>
                        <CardContent className="p-6">
                            <form onSubmit={handleUpdate} className="space-y-4">
                                <div className="space-y-2">
                                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Nombre del Producto</label>
                                    <Input 
                                        className="bg-slate-800 border-slate-700 text-white text-lg font-bold"
                                        value={editingItem.name}
                                        onChange={(e) => setEditingItem({...editingItem, name: e.target.value})}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Precio ($)</label>
                                        <Input 
                                            type="number"
                                            step="0.01"
                                            className="bg-slate-800 border-slate-700 text-white text-xl font-black font-display"
                                            value={editingItem.price}
                                            onChange={(e) => setEditingItem({...editingItem, price: parseFloat(e.target.value) || 0})}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Ubicación</label>
                                        <Input 
                                            className="bg-slate-800 border-slate-700 text-white font-bold"
                                            value={editingItem.location}
                                            onChange={(e) => setEditingItem({...editingItem, location: e.target.value})}
                                        />
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Categoría</label>
                                        <Input 
                                            className="bg-slate-800 border-slate-700 text-white"
                                            value={editingItem.category}
                                            onChange={(e) => setEditingItem({...editingItem, category: e.target.value})}
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">SKU</label>
                                        <Input 
                                            className="bg-slate-800 border-slate-700 text-white font-mono"
                                            value={editingItem.sku}
                                            onChange={(e) => setEditingItem({...editingItem, sku: e.target.value})}
                                        />
                                    </div>
                                </div>
                                <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white font-display text-xl uppercase py-6 mt-4 shadow-lg shadow-primary/20">
                                    <Save className="mr-2 h-6 w-6" /> Guardar Cambios
                                </Button>
                            </form>
                        </CardContent>
                    </Card>
                </motion.div>
            </motion.div>
        )}
      </AnimatePresence>

      <BottomNav />
    </div>
  );
}
