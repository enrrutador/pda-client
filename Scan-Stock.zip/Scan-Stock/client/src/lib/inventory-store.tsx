import React, { createContext, useContext, useEffect, useState } from "react";
import { get, set } from "idb-keyval";

export interface Product {
  id: string;
  name: string;
  barcode: string;
  sku: string;
  category: string;
  price: number;
}

export interface InventoryItem extends Product {
  quantity: number;
  lastScanned: string;
  location: string;
}

// Base de datos local para un negocio (Ferretería/Suministros)
const MOCK_DB: Record<string, Product> = {
  "7501055310014": { id: "1", name: "Martillo de Uña 16oz", barcode: "7501055310014", sku: "FER-MAR-001", category: "Herramientas Manuales", price: 15.50 },
  "7501055320020": { id: "2", name: "Taladro Percutor 1/2\"", barcode: "7501055320020", sku: "FER-TAL-050", category: "Herramientas Eléctricas", price: 89.99 },
  "7501055330036": { id: "3", name: "Cinta Métrica 5m", barcode: "7501055330036", sku: "FER-CIN-005", category: "Medición", price: 8.00 },
  "7501055340042": { id: "4", name: "Juego de Destornilladores (6 pzas)", barcode: "7501055340042", sku: "FER-DES-006", category: "Herramientas Manuales", price: 22.00 },
  "7501055350058": { id: "5", name: "Pinzas de Corte 8\"", barcode: "7501055350058", sku: "FER-PIN-008", category: "Herramientas Manuales", price: 12.75 },
  "7501055360064": { id: "6", name: "Lámpara LED 100W", barcode: "7501055360064", sku: "FER-LAM-100", category: "Iluminación", price: 5.50 },
  "7501055370070": { id: "7", name: "Extension Eléctrica 10m", barcode: "7501055370070", sku: "FER-EXT-010", category: "Electricidad", price: 18.00 },
};

interface InventoryContextType {
  items: InventoryItem[];
  addItem: (item: InventoryItem) => void;
  updateItem: (id: string, updates: Partial<InventoryItem>) => void;
  scanItem: (barcode: string) => Promise<{ success: boolean; item?: InventoryItem; message: string }>;
  updateQuantity: (id: string, delta: number) => void;
  recentScans: InventoryItem[];
  isLoading: boolean;
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined);

const STORAGE_KEY = "rapidscan_inventory_v1";

export function InventoryProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Cargar datos desde IndexedDB al iniciar
  useEffect(() => {
    async function loadData() {
      try {
        const savedItems = await get<InventoryItem[]>(STORAGE_KEY);
        if (savedItems && savedItems.length > 0) {
          setItems(savedItems);
        } else {
          // Inicializar con datos de ejemplo si está vacío
          const initialInventory: InventoryItem[] = [
            { ...MOCK_DB["7501055310014"], quantity: 24, lastScanned: new Date().toISOString(), location: "PASILLO-A1" },
            { ...MOCK_DB["7501055320020"], quantity: 8, lastScanned: new Date().toISOString(), location: "MOSTRADOR-B" },
            { ...MOCK_DB["7501055330036"], quantity: 45, lastScanned: new Date().toISOString(), location: "PASILLO-A3" },
          ];
          setItems(initialInventory);
          await set(STORAGE_KEY, initialInventory);
        }
      } catch (error) {
        console.error("Error loading from IndexedDB:", error);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  // Guardar en IndexedDB cada vez que items cambie
  useEffect(() => {
    if (!isLoading) {
      set(STORAGE_KEY, items).catch(err => console.error("Error saving to IndexedDB:", err));
    }
  }, [items, isLoading]);

  const addItem = (item: InventoryItem) => {
    setItems(prev => [item, ...prev]);
  };

  const updateItem = (id: string, updates: Partial<InventoryItem>) => {
    setItems(prev => prev.map(item => item.id === id ? { ...item, ...updates } : item));
  };

  const scanItem = async (barcode: string) => {
    const existingItemIndex = items.findIndex(i => i.barcode === barcode);
    
    if (existingItemIndex >= 0) {
      const newItems = [...items];
      newItems[existingItemIndex] = {
        ...newItems[existingItemIndex],
        quantity: newItems[existingItemIndex].quantity + 1,
        lastScanned: new Date().toISOString()
      };
      setItems(newItems);
      return { success: true, item: newItems[existingItemIndex], message: "Stock actualizado (+1)" };
    } 

    const catalogProduct = MOCK_DB[barcode];
    if (catalogProduct) {
      const newItem: InventoryItem = {
        ...catalogProduct,
        quantity: 1,
        lastScanned: new Date().toISOString(),
        location: "RECEPCIÓN"
      };
      setItems(prev => [newItem, ...prev]);
      return { success: true, item: newItem, message: "Añadido al inventario desde catálogo" };
    }

    return { success: false, message: "Producto no registrado" };
  };

  const updateQuantity = (id: string, delta: number) => {
    setItems(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, quantity: Math.max(0, item.quantity + delta) };
      }
      return item;
    }));
  };

  const recentScans = [...items]
    .sort((a, b) => new Date(b.lastScanned).getTime() - new Date(a.lastScanned).getTime())
    .slice(0, 5);

  return (
    <InventoryContext.Provider value={{ items, addItem, updateItem, scanItem, updateQuantity, recentScans, isLoading }}>
      {children}
    </InventoryContext.Provider>
  );
}

export function useInventory() {
  const context = useContext(InventoryContext);
  if (!context) throw new Error("useInventory must be used within InventoryProvider");
  return context;
}
